# MASTER VIDEO PRODUCTION TEMPLATE

## Informasi proyek
- Judul:
- Premis:
- Genre:
- Pesan utama:
- Target emosi:
- Platform:
- Rasio: 9:16
- Durasi: 60 detik
- Struktur: 6 x 10 detik

## Hook
Tulis visual dan/atau kalimat pembuka yang membuat penonton berhenti scroll dalam 0–3 detik.

## Sinopsis
[Tulis satu paragraf yang memiliki awal, konflik, klimaks, dan akhir.]

## Character Bible
| Karakter | Peran | Wajah/rambut | Pakaian/warna | Ciri khas | Aturan konsistensi |
|---|---|---|---|---|---|

## World Bible
- Lokasi:
- Waktu:
- Cuaca:
- Tata ruang:
- Properti penting:
- Palet warna:
- Sumber cahaya:
- Detail yang harus konsisten:

## Storyboard 6 adegan
| Adegan | Waktu | Tujuan cerita | Visual utama | Emosi | Transisi |
|---|---|---|---|---|---|
| 1 | 00–10 | Hook + konteks | | | |
| 2 | 10–20 | Pengenalan | | | |
| 3 | 20–30 | Konflik naik | | | |
| 4 | 30–40 | Titik balik | | | |
| 5 | 40–50 | Klimaks/resolusi | | | |
| 6 | 50–60 | Penutup + CTA | | | |

## Prompt adegan [nomor] — [judul adegan]
**Durasi:** 10 detik  
**Tujuan:**  

### Prompt utama
[Lokasi dan waktu secara eksplisit. Desain karakter secara eksplisit. Posisi karakter. Aksi berurutan. Ekspresi. Properti. Pencahayaan. Gaya visual. Kamera. Komposisi vertikal.]

### Shot breakdown
| Timestamp | Shot/framing | Aksi | Gerak kamera | Ekspresi/emosi | Audio |
|---|---|---|---|---|---|
| 0–3 dtk | | | | | |
| 3–6 dtk | | | | | |
| 6–10 dtk | | | | | |

### Dialog / narasi
[Tulis persis atau tulis: tanpa dialog.]

### Subtitle
| Timestamp | Teks subtitle | Kata aksen |
|---|---|---|

### Audio
- Musik:
- Ambience:
- SFX:
- Level/mix:

### Transisi
- Masuk:
- Keluar:

### Negative prompt
No teleportation, no sudden appearance/disappearance, no character redesign, no face change, no extra fingers or limbs, no floating objects, no impossible physics, no broken anatomy, no flicker, no jitter, no random camera shake, no unreadable generated text, no watermark, no unwanted logos.

## Paket editing
- Urutan klip:
- Subtitle:
- Musik dan SFX:
- Transisi:
- Color grading:
- CTA:
- Ekspor: 1080x1920, 9:16, 30 fps (sesuaikan kemampuan sumber).

## Pemeriksaan akhir
Gunakan `QUALITY_CHECKLIST.md`.
