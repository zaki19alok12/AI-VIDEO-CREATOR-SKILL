# INPUT VIDEO (opsional)

Pengguna cukup mengirim:

**Judul:** [TULIS JUDUL DI SINI]

Opsional:
- Fakta/cerita yang wajib dimasukkan:
- Hal yang tidak boleh ditampilkan:
- Durasi khusus:

Jika hanya judul yang diberikan, gunakan semua standar default dari `SKILL.md`. Jangan menunda proses dengan pertanyaan preferensi yang tidak diperlukan.
