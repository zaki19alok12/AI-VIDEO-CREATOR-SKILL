# QUALITY CHECKLIST

## Cerita
- [ ] Hook muncul pada 0–3 detik.
- [ ] Cerita mudah dipahami tanpa penjelasan tambahan.
- [ ] Konflik dan klimaks terasa.
- [ ] Ending memberi kesan atau mengundang interaksi.
- [ ] Fakta tidak dicampur dengan dramatisasi tanpa penanda.

## Visual dan kontinuitas
- [ ] Wajah, rambut, pakaian, proporsi, dan warna karakter konsisten.
- [ ] Lokasi dan tata ruang tidak berubah tanpa alasan.
- [ ] Properti tidak muncul/hilang tiba-tiba.
- [ ] Aksi fisik berurutan dan masuk akal.
- [ ] Arah pandang dan gerak konsisten.
- [ ] Kamera stabil dan gerak kamera punya tujuan.
- [ ] Tidak ada flicker, jitter, anatomi rusak, atau objek melayang.

## Audio dan teks
- [ ] Dialog/narasi sinkron dengan aksi.
- [ ] Subtitle sesuai ucapan.
- [ ] Subtitle terbaca di layar ponsel.
- [ ] Musik tidak menutupi dialog.
- [ ] SFX muncul tepat saat aksi.

## Ekspor
- [ ] Rasio 9:16.
- [ ] Resolusi target 1080x1920 bila tersedia.
- [ ] Durasi sesuai rencana.
- [ ] Tidak ada watermark yang tidak diinginkan.
- [ ] CTA tidak menutupi subjek utama.
