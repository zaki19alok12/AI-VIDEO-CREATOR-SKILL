# ANALISIS GAYA REFERENSI

Video contoh yang diberikan pengguna berdurasi sekitar 43,5 detik, 30 fps, format vertikal.

Ciri yang dijadikan acuan umum (bukan disalin adegan atau ceritanya):
- Animasi karakter kartun sederhana dengan tampilan 2D/3D stylized dan lingkungan low-poly.
- Interior rumah dan lingkungan malam dengan pencahayaan hangat dari lampu, kontras dengan biru gelap di luar.
- Komposisi vertikal dan framing seperti film pendek.
- Karakter memiliki ekspresi yang mudah dibaca.
- Subtitle tebal di bagian bawah/tengah layar; kata penting diberi warna aksen terang.
- Cerita naratif dengan detail waktu/latar, situasi, kejadian, dan pertanyaan penutup kepada penonton.
- Mood sinematik dan dramatis, tidak terlalu ramai.

Penerapan:
Jadikan ini pedoman estetika. Jangan menyalin karakter, alur, dialog, logo, atau aset video referensi. Buat cerita dan desain orisinal.
